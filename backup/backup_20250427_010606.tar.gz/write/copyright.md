---
title: copyright
description: copyright of this script
date: 2025-04-17
tags: copyright
draft: true
---

This post is drafted. 

All rights reserved to [RayCC](https://github.com/raycc51)
